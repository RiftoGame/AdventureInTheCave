# کتابخانه ها
import pygame
import sys
import random
# شروع پای گیم
pygame.init()
# تنظیمات صفحه نمایش
screen = pygame.display.set_mode()
x, y = screen.get_size()
clock = pygame.time.Clock()
win = pygame.display.set_mode((x, y))
# متغیر ها
xcore_all = 0
gravity = 10.75
Steve_jump = 0
Steve_left_right = "Right"
Game_s = "Loading"
Box_xcore = x + 50
Coin = 4
hy = x + 350
bat_list = []
a = 1
tnt_list = []
Game_False = "off"
next = 1
Cracter = "Steve"
Items = "off"
p_hp = 1
c_move = "True"
wall_active = "off"
wall_hp = 3
# وارد کردن عکس ها
Earth_img = pygame.image.load("Files/Image/Earth_img.png")
BackGround = pygame.image.load("Files/Image/Background.png")
Coin_img = pygame.image.load("Files/Image/Coin_img.png")
Coin_box = pygame.image.load("Files/Image/Coin_box.png")
bat_img = pygame.image.load("Files/Image/bat.png")
tnt_img = pygame.image.load("Files/Image/TNT_img.png")
Explosin = pygame.transform.scale2x(pygame.image.load("Files/Image/Explosion.png"))
Loading_screen = pygame.image.load("Files/Image/Loading_screen/Loading.png")
Loading = pygame.image.load("Files/Image/Loading_screen/Loading2.png")
wall = pygame.image.load("Files/Image/Wall.png")
pickaxs = pygame.image.load("Files/Image/Pickaxs/pickaxs.png")
hp1 = pygame.transform.scale2x(pygame.image.load("Files/Image/Pickaxs/Hp_1.png"))
hp2 = pygame.transform.scale2x(pygame.image.load("Files/Image/Pickaxs/Hp_2.png"))
hp3 = pygame.transform.scale2x(pygame.image.load("Files/Image/Pickaxs/Hp_3.png"))
hp4 = pygame.transform.scale2x(pygame.image.load("Files/Image/Pickaxs/Hp_4.png"))
    # عکس های دکمه ها
Shop = pygame.image.load("Files/Image/Icon/Buy_skin.png")
Shop_next = pygame.image.load("Files/Image/Icon/Buy_next.png")
Shop_buy = pygame.image.load("Files/Image/Icon/Buy_icon.png")
Shop_exit = pygame.image.load("Files/Image/Icon/Buy_exit.png")
Home = pygame.image.load("Files/Image/Icon/Home.png")
Exit_game = pygame.image.load("Files/Image/Icon/Exit_game.png")
Exit = pygame.transform.scale2x(pygame.image.load("Files/Image/Icon/Exit.png"))
buy_item = pygame.image.load("Files/Image/Icon/Buy_item.png")
buy_pickaxs = pygame.image.load("Files/Image/Icon/Buy_pickaxs.png")

    # عکس های کاراکتر ها
        # کاراکتر استیو
Steve_img = pygame.image.load("Files/Image/Cracters/Steve/Steve_img.png")
Steve_img2 = pygame.image.load("Files/Image/Cracters/Steve/Steve_img2.png")
Steve_down_img = pygame.image.load("Files/Image/Cracters/Steve/Steve_down.png")
Steve_pickaxs = pygame.image.load("Files/Image/Cracters/Steve/Steve_pickaxs.png")
        # کاراکتر الکس
Alex_img = pygame.image.load("Files/Image/Cracters/Alex/Alex_img.png")
Alex_img2 = pygame.image.load("Files/Image/Cracters/Alex/Alex_img2.png")
Alex_down_img = pygame.image.load("Files/Image/Cracters/Alex/Alex_img_down.png")
Alex_pickaxs = pygame.image.load("Files/Image/Cracters/Alex/Alex_pickaxs.png")
        # کاراکتر علی
Ali_img = pygame.image.load("Files/Image/Cracters/Ali/Ali_img.png")
Ali_img2 = pygame.image.load("Files/Image/Cracters/Ali/Ali_img2.png")
Ali_down_img = pygame.image.load("Files/Image/Cracters/Ali/Ali_img_down.png")
Ali_pickaxs = pygame.image.load("Files/Image/Cracters/Ali/Ali_pickaxs.png")
        # کاراکتر گلی
Goli_img = pygame.image.load("Files/Image/Cracters/Goli/Goli_img.png")
Goli_img2 = pygame.image.load("Files/Image/Cracters/Goli/Goli_img2.png")
Goli_down_img = pygame.image.load("Files/Image/Cracters/Goli/Goli_img_down.png")
Goli_pickaxs = pygame.image.load("Files/Image/Cracters/Goli/Goli_pickaxs.png")
        # کاراکتر ایمو
Imo_img = pygame.image.load("Files/Image/Cracters/Imo/Imo_img.png")
Imo_img2 = pygame.image.load("Files/Image/Cracters/Imo/Imo_img2.png")
Imo_down_img = pygame.image.load("Files/Image/Cracters/Imo/Imo_img_down.png")
Imo_pickaxs = pygame.image.load("Files/Image/Cracters/Imo/Imo_pickaxs.png")
# مربع دور عکس کاراکتر های لودشده
Steve_img_rect = Steve_img.get_rect(center=(150, y - 180))
Alex_img_rect = Alex_img.get_rect(center=(150, y - 180))
Ali_img_rect = Ali_img.get_rect(center=(150, y - 180))
Goli_img_rect = Goli_img.get_rect(center=(150, y - 180))
Imo_img_rect = Imo_img.get_rect(center=(150, y - 180))
# مربع دور عکس های دیگر
Box_rect = Coin_box.get_rect(center=(x + 80, y - 120))
Loading_rect = Loading.get_rect(center=(-2000, y - 20))
Loading_screen_rect = Loading_screen.get_rect(center=(0, 0))
pickaxs_rect = pickaxs.get_rect(center=(60, 200))
hp1_rect = hp1.get_rect(center=(180, 200))
hp2_rect = hp2.get_rect(center=(180, 200))
hp3_rect = hp3.get_rect(center=(180, 200))
hp4_rect = hp4.get_rect(center=(180, 200))
wall_rect = wall.get_rect(center=(x + 1600, 0))
# مربع دور عکس های دکمه ها
Shop_rect = Shop.get_rect(center=(x - 60, 90))
Shop_next_rect = Shop_next.get_rect(center=(x - 60, 180))
Shop_buy_rect = Shop_buy.get_rect(center=(x - 60, 270))
Shop_exit_rect = Shop_exit.get_rect(center=(x - 60, 360))
Home_rect = Home.get_rect(center=(x - 60, 90))
Exit_game_rect = Exit_game.get_rect(center=(x - 60, 270))
Exit_rect = Exit.get_rect(center=(x // 2, y // 2 - 50))
buy_pickaxs_rect = buy_pickaxs.get_rect(center=(x // 2, y // 2))
# وارد کردن صدا های بازی
jump = pygame.mixer.Sound("Files/Sound/jump.mp3")
wagon = pygame.mixer.Sound("Files/Sound/wagon.mp3")
explosin2 = pygame.mixer.Sound("Files/Sound/exploding.mp3")
dameg = pygame.mixer.Sound("Files/Sound/dameg.mp3")
coin2 = pygame.mixer.Sound("Files/Sound/coins.mp3")
landslide = pygame.mixer.Sound("Files/Sound/landslide.mp3")
Break_1 = pygame.mixer.Sound("Files/Sound/Break.mp3")
Break_p = pygame.mixer.Sound("Files/Sound/Break_p.mp3")
close = pygame.mixer.Sound("Files/Sound/Close.mp3")
open = pygame.mixer.Sound("Files/Sound/Open.mp3")
Collect = pygame.mixer.Sound("Files/Sound/Collect.mp3")

# وارد کردن فونت متن ها
Game_Font = pygame.font.Font("Files/Font/GTA.otf", 40)
Game_Font2 = pygame.font.Font("Files/Font/GTA.otf", 130)
Game_Font3 = pygame.font.Font("Files/Font/GTA.otf", 30)
Game_Font4 = pygame.font.Font("Files/Font/GTA.otf", 100)


# متن هایی که در صفحه نمایش داده میشه
def Score(mnb):
    if mnb == "True":
        text2 = Game_Font.render(f"Your Coins: {Coin}", True, ("#000000"))
        text2_rect = text2.get_rect(center=(215, 70))
        win.blit(text2, text2_rect)
        text1 = Game_Font.render(f"Your Coins: {Coin}", True, ("#37e233"))
        text1_rect = text1.get_rect(center=(210, 65))
        win.blit(text1, text1_rect)
    elif mnb == "False":
        text3 = Game_Font.render(f"Your Coins: {Coin}", True, ("#000000"))
        text3_rect = text3.get_rect(center=(x // 2, 70))
        win.blit(text3, text3_rect)
        text4 = Game_Font.render(f"Your Coins: {Coin}", True, ("#37e233"))
        text4_rect = text4.get_rect(center=(x // 2 + 5, 65))
        win.blit(text4, text4_rect)
    elif mnb == "Did":
        text5 = Game_Font.render(f"Your Coins: {Coin}", True, ("#000000"))
        text5_rect = text5.get_rect(center=(x // 2, 70))
        win.blit(text5, text5_rect)
        text6 = Game_Font.render(f"Your Coins: {Coin}", True, ("#37e233"))
        text6_rect = text6.get_rect(center=(x // 2 + 5, 65))
        win.blit(text6, text6_rect)
        text7 = Game_Font.render(f"You Die", True, ("#000000"))
        text7_rect = text7.get_rect(center=(x // 2, 120))
        win.blit(text7, text7_rect)
        text8 = Game_Font.render(f"You Die", True, ("#37e233"))
        text8_rect = text8.get_rect(center=(x // 2 + 5, 115))
        win.blit(text8, text8_rect)
    elif mnb == "Loading":
        text10 = Game_Font2.render("Rifto Game", True, ("#000000"))
        text10_rect = text10.get_rect(center=(x // 2, 300))
        win.blit(text10, text10_rect)
        text11 = Game_Font2.render("Rifto Game", True, ("#ff0000"))
        text11_rect = text11.get_rect(center=(x // 2 + 5, 295))
        win.blit(text11, text11_rect)
        text12 = Game_Font3.render("Loading", True, ("#000000"))
        text12_rect = text12.get_rect(center=(x // 2, y - 85))
        win.blit(text12, text12_rect)
        text13 = Game_Font3.render("Loading", True, ("#37e233"))
        text13_rect = text13.get_rect(center=(x // 2 + 5, y - 90))
        win.blit(text13, text13_rect)

# تولید خفاش ها در ارتفاع های متفاوت و ساخت مربع های دور آنها
def g_bat():
    random_bat = random.randrange(90, y - 50)
    bat_rect = bat_img.get_rect(midtop=(x + 60, random_bat))
    return bat_rect

# به حرکت در آوردن خفاش ها
def move_bat(bats):
    for bat in bats:
        bat.centerx -= 45
    inside_bats = [bat for bat in bats if bat.right > -200]
    return inside_bats

# نشان دادن خفاش ها در صفحه
def display_bats(bats):
    for bat in bats:
        win.blit(bat_img, bat)

# برسی برخورد کاراکتر با خفاش ها
def check(bats):
    global Game_s, Game_False
    for bat in bats:
        if Cracter == "Steve":
            if Steve_img_rect.colliderect(bat):
                Game_s = "Did"
                Game_False = "bat"
                bat_list.clear()
                dameg.play()
        if Cracter == "Alex":
            if Alex_img_rect.colliderect(bat):
                Game_s = "Did"
                Game_False = "bat"
                bat_list.clear()
                dameg.play()
        if Cracter == "Ali":
            if Ali_img_rect.colliderect(bat):
                Game_s = "Did"
                Game_False = "bat"
                bat_list.clear()
                dameg.play()
        if Cracter == "Goli":
            if Goli_img_rect.colliderect(bat):
                Game_s = "Did"
                Game_False = "bat"
                bat_list.clear()
                dameg.play()
        if Cracter == "Imo":
            if Imo_img_rect.colliderect(bat):
                Game_s = "Did"
                Game_False = "bat"
                bat_list.clear()
                dameg.play()

# برسی برخورد کاراکتر با مواد منفجره
def check_tnt(tnts):
    global Game_s, Game_False
    for tnt in tnts:
        if Cracter == "Steve":
            if Steve_img_rect.colliderect(tnt):
                Game_s = "Did"
                Game_False = "tnt"
                explosin2.play()
        if Cracter == "Alex":
            if Alex_img_rect.colliderect(tnt):
                Game_s = "Did"
                Game_False = "tnt"
                explosin2.play()
        if Cracter == "Ali":
            if Ali_img_rect.colliderect(tnt):
                Game_s = "Did"
                Game_False = "tnt"
                explosin2.play()
        if Cracter == "Goli":
            if Goli_img_rect.colliderect(tnt):
                Game_s = "Did"
                Game_False = "tnt"
                explosin2.play()
        if Cracter == "Imo":
            if Imo_img_rect.colliderect(tnt):
                Game_s = "Did"
                Game_False = "tnt"
                explosin2.play()
        

# تایمر برای تولید خفاش و مواد منفجره
def Timer():
    global a
    for a in range(a + 2):
        a + 1

# تولید مواد منفجره و ساخت مربع دور آنها
def g_tnt():
    global a, tnt_rect2
    tnt_rect = tnt_img.get_rect(midtop=(x + 60, y - 200))
    if tnt_rect.centerx >= -100:
        a = 1
    tnt_rect2 = tnt_rect
    return tnt_rect

# به حرکت در آوردن مواد منفجره
def move_tnt(tnts):
    for tnt in tnts:
        tnt.centerx -= 25
    inside_tnts = [tnt for tnt in tnts if tnt.right > -200]
    return inside_tnts

# نمایش دادن مواد منفجره در صفحه
def display_tnts(tnts):
    for tnt in tnts:
        win.blit(tnt_img, tnt)

# برسی موقعیت مواد منفجره برای پخش صدای واگن مواد منفجره
def tnt_ceck2():
    if tnt_list:
        for tnt in tnt_list:
            if x - 100 >= tnt.centerx >= x - 105:
                wagon.play()
            if 100 >= tnt.centerx >= 105:
                wagon.play()


def c_name():
    if next == 1:
        text_steve = Game_Font4.render("Steve", True, ("#66504c"))
        text_steve_rect = text_steve.get_rect(center=(x // 2, 450))
        win.blit(text_steve, text_steve_rect)
    if next == 2:
        text_Alex = Game_Font4.render("Alex", True, ("#f37028"))
        text_Alex_rect = text_Alex.get_rect(center=(x // 2, 450))
        win.blit(text_Alex, text_Alex_rect)
    if next == 3:
        text_Ali = Game_Font4.render("Ali", True, ("#174c52"))
        text_Ali_rect = text_Ali.get_rect(center=(x // 2, 450))
        win.blit(text_Ali, text_Ali_rect)
    if next == 4:
        text_Goli = Game_Font4.render("Goli", True, ("#fcb654"))
        text_Goli_rect = text_Goli.get_rect(center=(x // 2, 450))
        win.blit(text_Goli, text_Goli_rect)
    if next == 5:
        text_Imo = Game_Font4.render("Imo", True, ("#ffa0c2"))
        text_Imo_rect = text_Imo.get_rect(center=(x // 2, 450))
        win.blit(text_Imo, text_Imo_rect)


def c5():
    c5 = Game_Font4.render("Your coins are low", True, ("#ff0000"))
    c5_rect = c5.get_rect(center=(x // 2, 110))
    win.blit(c5, c5_rect)


def check_wall():
    global c_move
    if Cracter == "Steve":
        if Steve_img_rect.colliderect(wall_rect):
            c_move = "False"
        else:
            c_move = "True"
    if Cracter == "Alex":
        if Alex_img_rect.colliderect(wall_rect):
            c_move = "False"
        else:
            c_move = "True"
    if Cracter == "Ali":
        if Ali_img_rect.colliderect(wall_rect):
            c_move = "False"
        else:
            c_move = "True"
    if Cracter == "Goli":
        if Goli_img_rect.colliderect(wall_rect):
            c_move = "False"
        else:
            c_move = "True"
    if Cracter == "Imo":
        if Imo_img_rect.colliderect(wall_rect):
            c_move = "False"
        else:
            c_move = "True"
# چرخه وایل ترو
while True:
    # نماین دادن تصوید پشت بازی 
    win.blit(BackGround, (0, 0))
    # نماین زمین و بینهایت کردن آن
    win.blit(Earth_img, (xcore_all, y - 110))
    win.blit(Earth_img, (xcore_all + 3840, y - 110))
    win.blit(Earth_img, (xcore_all + 7680, y - 110))
    if -7675 >= xcore_all >= -7680:
        xcore_all = 0
    # برسی دکمه های زده شده برای انجام فعالیت در نظر گرفته شده
        # چرخه فور برای جست و جو حرکت موس و کیبورد
    for event in pygame.event.get():
        # دکمه خروج از بازی با دکمه خروج برنامه سمت چپ بالا صفحه
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        # چرخه فور برای جست و جو دکمه های فشار داده شده
        if event.type == pygame.KEYDOWN:
            # دکمه ال برای صفحه خروج
            if event.key == pygame.K_l and Game_s == "False":
                Game_s = "Exit"
            # دکمه وای برای تایید خروج از بازی
            if event.key == pygame.K_y and Game_s == "Exit":
                pygame.quit()
                sys.exit()
            # دکمه ان برای کنسل کردن خروج از بازی
            if event.key == pygame.K_n:
                if Game_s == "Exit":
                    Game_s = "False"
                if Game_s == "Shop_item":
                    Game_s = "True"
                    close.play()
            # دکمه دی برای حرکت کاراکتر به سمت راست
            if event.key == pygame.K_d and Game_s == "True" and c_move == "True":
                if Cracter == "Steve":
                    if Steve_img_rect.centerx < x // 2 + 50:
                        Steve_img_rect.centerx += 25
                    if Steve_img_rect.centerx >= x // 2 + 50 and Game_s == "True":
                        xcore_all -= 25
                        Box_rect.centerx -= 25
                        if wall_active == "on":
                            wall_rect.centerx -= 25
                if Cracter == "Alex":
                    if Alex_img_rect.centerx < x // 2 + 50:
                        Alex_img_rect.centerx += 25
                    if Alex_img_rect.centerx >= x // 2 + 50 and Game_s == "True":
                        xcore_all -= 25
                        Box_rect.centerx -= 25
                        if wall_active == "on":
                            wall_rect.centerx -= 25
                if Cracter == "Ali":
                    if Ali_img_rect.centerx < x // 2 + 50:
                        Ali_img_rect.centerx += 25
                    if Ali_img_rect.centerx >= x // 2 + 50 and Game_s == "True":
                        xcore_all -= 25
                        Box_rect.centerx -= 25
                        if wall_active == "on":
                            wall_rect.centerx -= 25
                if Cracter == "Goli":
                    if Goli_img_rect.centerx < x // 2 + 50:
                        Goli_img_rect.centerx += 25
                    if Goli_img_rect.centerx >= x // 2 + 50 and Game_s == "True":
                        xcore_all -= 25
                        Box_rect.centerx -= 25
                        if wall_active == "on":
                            wall_rect.centerx -= 25
                if Cracter == "Imo":
                    if Imo_img_rect.centerx < x // 2 + 50:
                        Imo_img_rect.centerx += 25
                    if Imo_img_rect.centerx >= x // 2 + 50 and Game_s == "True":
                        xcore_all -= 25
                        Box_rect.centerx -= 25
                        if wall_active == "on":
                            wall_rect.centerx -= 25
                Steve_left_right = "Right"
            # دکمه ای برای حرکت کاراکتر به سمت چپ
            if event.key == pygame.K_a and Game_s == "True":
                if Cracter == "Steve":
                    if Steve_img_rect.centerx >= 250:
                        Steve_img_rect.centerx -= 25
                if Cracter == "Alex":
                    if Alex_img_rect.centerx >= 250:
                        Alex_img_rect.centerx -= 25
                if Cracter == "Ali":
                    if Ali_img_rect.centerx >= 250:
                        Ali_img_rect.centerx -= 25
                if Cracter == "Goli":
                    if Goli_img_rect.centerx >= 250:
                        Goli_img_rect.centerx -= 25
                if Cracter == "Imo":
                    if Imo_img_rect.centerx >= 250:
                        Imo_img_rect.centerx -= 25
                Steve_left_right = "Left"
            # دکمه دابل یو برای پرش کاراکتر
            if event.key == pygame.K_w and Game_s == "True":
                if Cracter == "Steve":
                    if Steve_img_rect.centery > 550:
                        Steve_jump = 0
                        Steve_jump -= 40
                if Cracter == "Alex":
                    if Alex_img_rect.centery >= 550:
                        Steve_jump = 0
                        Steve_jump -= 40
                if Cracter == "Ali":
                    if Ali_img_rect.centery >= 550:
                        Steve_jump = 0
                        Steve_jump -= 40
                if Cracter == "Goli":
                    if Goli_img_rect.centery >= 550:
                        Steve_jump = 0
                        Steve_jump -= 40
                if Cracter == "Imo":
                    if Imo_img_rect.centery >= 550:
                        Steve_jump = 0
                        Steve_jump -= 40
                jump.play()
            # دکمه ایی برای برداشتن سکه روی زمین
            if event.key == pygame.K_e and Game_s == "True":
                if Cracter == "Steve":
                    if Steve_img_rect.colliderect(Box_rect):
                        Box_rect.centerx = hy
                        Coin += 1
                        hy += 100
                        coin2.play()
                    if Steve_img_rect.colliderect(wall_rect) and Items == "Pickaxs":
                        if wall_hp == 3:
                            Break_1.play()
                        if wall_hp == 2:
                            Break_1.play()
                        wall_hp -= 1
                if Cracter == "Alex":
                    if Alex_img_rect.colliderect(Box_rect):
                        Box_rect.centerx = hy
                        Coin += 1
                        hy += 100
                        coin2.play()
                    if Alex_img_rect.colliderect(wall_rect) and Items == "Pickaxs":
                        if wall_hp == 3:
                            Break_1.play()
                        if wall_hp == 2:
                            Break_1.play()
                        wall_hp -= 1
                if Cracter == "Ali":
                    if Ali_img_rect.colliderect(Box_rect):
                        Box_rect.centerx = hy
                        Coin += 1
                        hy += 100
                        coin2.play()
                    if Ali_img_rect.colliderect(wall_rect) and Items == "Pickaxs":
                        if wall_hp == 3:
                            Break_1.play()
                        if wall_hp == 2:
                            Break_1.play()
                        wall_hp -= 1
                if Cracter == "Goli":
                    if Goli_img_rect.colliderect(Box_rect):
                        Box_rect.centerx = hy
                        Coin += 1
                        hy += 100
                        coin2.play()
                    if Goli_img_rect.colliderect(wall_rect) and Items == "Pickaxs":
                        if wall_hp == 3:
                            Break_1.play()
                        if wall_hp == 2:
                            Break_1.play()
                        wall_hp -= 1
                if Cracter == "Imo":
                    if Imo_img_rect.colliderect(Box_rect):
                        Box_rect.centerx = hy
                        Coin += 1
                        hy += 100
                        coin2.play()
                    if Imo_img_rect.colliderect(wall_rect) and Items == "Pickaxs":
                        if wall_hp == 3:
                            Break_1.play()
                        if wall_hp == 2:
                            Break_1.play()
                        wall_hp -= 1
            # دکمه اسپیس برای خروج از صفحه مرگ کاراکتر به صفحه اصلی
            if event.key == pygame.K_SPACE and Game_s == "Did":
                    Game_False = "off"
                    Game_s = "False"
            # دکمه آلت سمت چپ برای شروع بازی
            if event.key == pygame.K_LALT and Game_s == "False":
                Game_s = "True"
                tnt_list.clear()
                bat_list.clear()
                if Cracter == "Steve":
                    Steve_img_rect.centery = 720
                    Steve_img_rect.centerx = 150
                if Cracter == "Alex":
                    Alex_img_rect.centery = 720
                    Alex_img_rect.centerx = 150
                if Cracter == "Ali":
                    Ali_img_rect.centery = 720
                    Ali_img_rect.centerx = 150
                if Cracter == "Goli":
                    Goli_img_rect.centery = 720
                    Goli_img_rect.centerx = 150
                if Cracter == "Imo":
                    Imo_img_rect.centery = 720
                    Imo_img_rect.centerx = 150
            # دکمه کنترل سمت چپ برای متوقف یا استپ کردن بازی
            if event.key == pygame.K_LCTRL:
                Game_s = "Wait"
            # دکمه شیفت سمت چپ برای ادامه بازی
            if event.key == pygame.K_LSHIFT:
                Game_s = "True"
            # دکمه بی برای رفتن به صفحه خرید کاراکتر
            if event.key == pygame.K_b and Game_s == "False":
                Game_s = "Shop"
            # دکمه پایین برای رفتن به صفحه اصله از صفحه خرید کاراکتر
            if event.key == pygame.K_DOWN and Game_s == "Shop":
                Game_s = "False"
                Game_False == "off"
            # دکمه سمت راست برای نمایش کاراکتر بعدی
            if event.key == pygame.K_RIGHT and Game_s == "Shop":
                next += 1
                if next == 6:
                    next = 1
            # دکمه ام برای خرید کاراکتر مورد نظر
            if event.key == pygame.K_m and Game_s == "Shop":
                if next == 1:
                    Game_s = "False"
                    next = 1
                    Cracter = "Steve"
                if next == 2:
                    Game_s = "False"
                    next = 1
                    Cracter = "Alex"
                if next == 3:
                    Game_s = "False"
                    next = 1
                    Cracter = "Ali"
                if next == 4:
                    Game_s = "False"
                    next = 1
                    Cracter = "Goli"
                if next == 5:
                    Game_s = "False"
                    next = 1
                    Cracter = "Imo"
            # دکمه آر برای خروج از بازی به صفحه اصلی زمانی کخ بازی متوقف یا استپ است
            if event.key == pygame.K_r and Game_s == "Wait":
                Game_s = "False"
            if event.key == pygame.K_v and Game_s == "True":
                Game_s = "Shop_item"
                open.play()
            if event.key == pygame.K_p and Game_s == "Shop_item":
                if Coin >= 5:
                    Items = "Pickaxs"
                    Coin -= 5
                    Collect.play()
                    Game_s = "True"
    # شرط نمایش و فعال کردن کد های مورد نظر اگر بازی در حالت اجرا بود
    if Game_s == "True":
        if Coin >= 5 and wall_active == "off":
            wall_active = "on"
        if wall_active == "on":
            win.blit(wall, wall_rect)
            if wall_hp == 0:
                wall_rect.centery += 65
                landslide.play()
            if wall_rect.centery >= y:
                wall_active = "r"
            if wall_active == "r":
                p_hp -= 1
                wall_rect.centerx = x + 1600
                wall_active = "off"
        if wall_active == "off":
            wall_hp = 3
            c_move = "True"
            tnt_ceck2()
            bat_list = move_bat(bat_list)
            display_bats(bat_list)
            check(bat_list)
            if a == 200 and wall_active == "off":
                bat_list.append(g_bat())
            if 449 <= a <= 450 and wall_active == "off":
                tnt_list.append(g_tnt())
            display_tnts(tnt_list)
            check_tnt(tnt_list)
            tnt_list = move_tnt(tnt_list)
            Timer()
        if Items == "off":
            win.blit(buy_item, (0, 500))
        # شرط نمایش تصویر سمت راست کاراکتر ها برای حرکت به سمت راست
        if Steve_left_right == "Right":
            if Cracter == "Steve":
                win.blit(Steve_img, Steve_img_rect)
                if Items == "Pickaxs":
                    win.blit(Steve_pickaxs, Steve_img_rect)
            if Cracter == "Alex":
                win.blit(Alex_img, Alex_img_rect)
                if Items == "Pickaxs":
                    win.blit(Alex_pickaxs, Alex_img_rect)
            if Cracter == "Ali":
                win.blit(Ali_img, Ali_img_rect)
                if Items == "Pickaxs":
                    win.blit(Ali_pickaxs, Ali_img_rect)
            if Cracter == "Goli":
                win.blit(Goli_img, Goli_img_rect)
                if Items == "Pickaxs":
                    win.blit(Goli_pickaxs, Goli_img_rect)
            if Cracter == "Imo":
                win.blit(Imo_img, Imo_img_rect)
                if Items == "Pickaxs":
                    win.blit(Imo_pickaxs, Imo_img_rect)
        # شرط نمایش تصویر سمت چپ کاراکتر ها برای حرکت به سمت چپ
        if Steve_left_right == "Left":
            if Cracter == "Steve":
                win.blit(Steve_img2, Steve_img_rect)
            if Cracter == "Alex":
                win.blit(Alex_img2, Alex_img_rect)
            if Cracter == "Ali":
                win.blit(Ali_img2, Ali_img_rect)
            if Cracter == "Goli":
                win.blit(Goli_img2, Goli_img_rect)
            if Cracter == "Imo":
                win.blit(Imo_img2, Imo_img_rect)
        # ساخت جاذبه بازی برای کاراکتر ها
        if Cracter == "Steve":
            Steve_img_rect.centery += Steve_jump
            if Steve_img_rect.centery < 700:
                Steve_jump += gravity
            if Steve_img_rect.centery >= y - 180:
                Steve_jump = 0
        if Cracter == "Alix":
            Alex_img_rect.centery += Steve_jump
            if Alex_img_rect.centery < 700:
                Steve_jump += gravity
            if Alex_img_rect.centery >= y - 180:
                Steve_jump = 0
        if Cracter == "Ali":
            Ali_img_rect.centery += Steve_jump
            if Ali_img_rect.centery < 700:
                Steve_jump += gravity
            if Ali_img_rect.centery >= y - 180:
                Steve_jump = 0
        if Cracter == "Goli":
            Goli_img_rect.centery += Steve_jump
            if Goli_img_rect.centery < 700:
                Steve_jump += gravity
            if Goli_img_rect.centery >= y - 180:
                Steve_jump = 0
        if Cracter == "Imo":
            Imo_img_rect.centery += Steve_jump
            if Imo_img_rect.centery < 700:
                Steve_jump += gravity
            if Imo_img_rect.centery >= y - 180:
                Steve_jump = 0
        win.blit(Coin_box, Box_rect)
        win.blit(Coin_img, (50, 50))
        Score("True")
        if Items == "Pickaxs":
            win.blit(pickaxs, pickaxs_rect)
            if p_hp == 4:
                win.blit(hp4, hp4_rect)
            if p_hp == 3:
                win.blit(hp3, hp3_rect)
            if p_hp == 2:
                win.blit(hp2, hp2_rect)
            if p_hp == 1:
                win.blit(hp1, hp1_rect)
            if p_hp == 0:
                Items = "off"
                Break_p.play()
        if Items == "off" :
            p_hp = 4
        check_wall()
    # شرط نمایش و فعال کردن کد های مورد نظر اگر بازی در حالت صفحه اصلی بود 
    if Game_s == "False":
        win.blit(Exit_game, Exit_game_rect)
        bat_list.clear()
        Score("False")
        # شرط نمایش تصویر سمت راست کاراکتر ها برای حرکت به سمت راست
        if Steve_left_right == "Right":
            if Cracter == "Steve":
                win.blit(Steve_img, Steve_img_rect)
            if Cracter == "Alex":
                win.blit(Alex_img, Alex_img_rect)
            if Cracter == "Ali":
                win.blit(Ali_img, Ali_img_rect)
            if Cracter == "Goli":
                win.blit(Goli_img, Goli_img_rect)
            if Cracter == "Imo":
                win.blit(Imo_img, Imo_img_rect)
        # شرط نمایش تصویر سمت چپ کاراکتر ها برای حرکت به سمت چپ
        if Steve_left_right == "Left":
            if Cracter == "Steve":
                win.blit(Steve_img2, Steve_img_rect)
            if Cracter == "Alex":
                win.blit(Alex_img2, Alex_img_rect)
            if Cracter == "Ali":
                win.blit(Ali_img2, Ali_img_rect)
            if Cracter == "Goli":
                win.blit(Goli_img2, Goli_img_rect)
            if Cracter == "Imo":
                win.blit(Imo_img2, Imo_img_rect)
        # نمایش کاراکتر ها در موقعیت اول بازی
        if Cracter == "Steve":
            Steve_img_rect.centery = y - 180
            Steve_img_rect.centerx = 150
        if Cracter == "Alex":
            Alex_img_rect.centery = y - 180
            Alex_img_rect.centerx = 150
        if Cracter == "Ali":
            Ali_img_rect.centery = y - 180
            Ali_img_rect.centerx = 150
        if Cracter == "Goli":
            Goli_img_rect.centery = y - 180
            Goli_img_rect.centerx = 150
        if Cracter == "Imo":
            Imo_img_rect.centery = y - 180
            Imo_img_rect.centerx = 150
        win.blit(Shop, Shop_rect)
    # شرط نمایش و فعال کردن کد های مورد نظر اگر بازی در حالت توقف یا استپ بود
    if Game_s == "Wait":
        # نمایش دکمه خروج از بازی متوقف شده به صفحه اصلی
        win.blit(Home, Home_rect)
        #
        text6 = Game_Font.render("The Game Is Paused!", True, ("#000000"))
        text6_rect = text6.get_rect(center=(x // 2, 150))
        win.blit(text6, text6_rect)
        text5 = Game_Font.render("The Game Is Paused!", True, ("#37e233"))
        text5_rect = text5.get_rect(center=(x // 2 + 5, 155))
        win.blit(text5, text5_rect)
        # شرط نمایش تصویر سمت راست کاراکتر ها برای حرکت به سمت راست
        if Steve_left_right == "Right":
            if Cracter == "Steve":
                win.blit(Steve_img, Steve_img_rect)
            if Cracter == "Alex":
                win.blit(Alex_img, Alex_img_rect)
            if Cracter == "Ali":
                win.blit(Ali_img, Ali_img_rect)
            if Cracter == "Goli":
                win.blit(Goli_img, Goli_img_rect)
            if Cracter == "Imo":
                win.blit(Imo_img, Imo_img_rect)
        # شرط نمایش تصویر سمت چپ کاراکتر ها برای حرکت به سمت چپ
        if Steve_left_right == "Left":
            if Cracter == "Steve":
                win.blit(Steve_img2, Steve_img_rect)
            if Cracter == "Alex":
                win.blit(Alex_img2, Alex_img_rect)
            if Cracter == "Ali":
                win.blit(Ali_img2, Ali_img_rect)
            if Cracter == "Goli":
                win.blit(Goli_img2, Goli_img_rect)
            if Cracter == "Imo":
                win.blit(Imo_img2, Imo_img_rect)
    # شرط نمایش و فعال کردن کد های مورد نظر اگر بازی در حالت خرید کاراکتر بود
    if Game_s == "Shop":
        # نمایش دکمه ها برای تغییر کاراکتر-خرید کاراکتر و خروج به صفحه اصلی
        win.blit(Shop_next, Shop_next_rect)
        win.blit(Shop_buy, Shop_buy_rect)
        win.blit(Shop_exit, Shop_exit_rect)
        # شرط نمایش کاراکتر های مختلف
        if next == 1:
            win.blit(Steve_img, Steve_img_rect)
        if next == 2:
            win.blit(Alex_img, Alex_img_rect)
        if next == 3:
            win.blit(Ali_img, Ali_img_rect)
        if next == 4:
            win.blit(Goli_img, Goli_img_rect)
        if next == 5:
            win.blit(Imo_img, Imo_img_rect)
        c_name()
    # شرط نمایش و فعال کردن کد های مورد نظر اگر بازی در حالت مرگ کاراکتر بود
    if Game_s == "Did":
        Score("Did")
        # شرط نمایش تصویر مخصوص برخورد کاراکتر با مواد منفجره 
        if Game_False == "tnt":
            if Cracter == "Steve":
                win.blit(Explosin, Steve_img_rect)
            if Cracter == "Alex":
                win.blit(Explosin, Alex_img_rect)
            if Cracter == "Ali":
                win.blit(Explosin, Ali_img_rect)
            if Cracter == "Goli":
                win.blit(Explosin, Goli_img_rect)
            if Cracter == "Imo":
                win.blit(Explosin, Imo_img_rect)
        # شرط نمایش تصویر مخصوص برخورد کاراکتر با خفاش ها 
        if Game_False == "bat":
            if Cracter == "Steve":
                win.blit(Steve_down_img, Steve_img_rect)
            if Cracter == "Alex":
                win.blit(Alex_down_img, Alex_img_rect)
            if Cracter == "Ali":
                win.blit(Ali_down_img, Ali_img_rect)
            if Cracter == "Goli":
                win.blit(Goli_down_img, Goli_img_rect)
            if Cracter == "Imo":
                win.blit(Imo_down_img, Imo_img_rect)
            # پایین افتادن کاراکتر بعد از برخورد با خفاش ها
            if Cracter == "Steve":
                Steve_img_rect.centery += Steve_jump
                if Steve_img_rect.centery < 700:
                    Steve_jump += gravity
            if Cracter == "Alix":
                Alex_img_rect.centery += Steve_jump
                if Alex_img_rect.centery < 700:
                    Steve_jump += gravity
            if Cracter == "Ali":
                Ali_img_rect.centery += Steve_jump
                if Ali_img_rect.centery < 700:
                    Steve_jump += gravity
            if Cracter == "Goli":
                Goli_img_rect.centery += Steve_jump
                if Goli_img_rect.centery < 700:
                    Steve_jump += gravity
            if Cracter == "Imo":
                Imo_img_rect.centery += Steve_jump
                if Imo_img_rect.centery < 700:
                    Steve_jump += gravity
    # شرط نمایش و فعال کردن کد های مورد نظر اگر بازی در حالت خروج یا صفحه خروج بود
    if Game_s == "Exit":
        # نمایش تصویر تایید خروج از بازی
        win.blit(Exit, Exit_rect)
    # شرط نمایش و فعال کردن کد های مورد نظر اگر بازی در حالت لودینگ اول بازی بود      
    if Game_s == "Loading":
        # نمایش تصویر پشت متن ها
        win.blit(Loading_screen, Loading_screen_rect)
        Score("Loading")
        # نماین و حرکت کردن نوار رنگی لودینگ
        win.blit(Loading, Loading_rect)
        Loading_rect.centerx += 40
        if Loading_rect.centerx >= -200:
            Game_s = "False"
    if Game_s == "Shop_item":
        win.blit(buy_pickaxs, buy_pickaxs_rect)
        if Coin < 5:
            c5()

    # تنظیم فریم ریت یا نمایش تصویر در ثانیه بازی
    pygame.display.update()
    clock.tick(60)
